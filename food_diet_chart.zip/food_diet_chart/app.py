import os
import streamlit as st
from auth import authenticate_user, save_user
from diet_plans import recommend_diet
from foods_data import food_items
from datetime import datetime

st.set_page_config(page_title="Smart Diet App", layout="wide")

# 🔧 Add background image via custom CSS
def add_background():
    st.markdown("""
    <style>
    .stApp {
        background-image: url("https://i.pinimg.com/736x/9f/37/86/9f37863b52eda41e96808fe6f6e0bf2a.jpg");
        background-size: cover;
        
    }
    .st-emotion-cache-1kyxreq {
        background-color: rgba(255, 255, 255, 0.85);
        padding: 20px;
        border-radius: 10px;
    }
    </style>
    """, unsafe_allow_html=True)

add_background()

# Initialize Session State
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "meal_log" not in st.session_state:
    st.session_state.meal_log = {"Breakfast": [], "Lunch": [], "Dinner": [], "Snacks": []}
if "target_calories" not in st.session_state:
    st.session_state.target_calories = 2000

UPLOAD_DIR = "uploaded_images"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# 🔐 Login
def login_page():
    st.title("🔐 Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        if authenticate_user(username, password):
            st.session_state.logged_in = True
            st.session_state.username = username
            st.success("Logged in successfully!")
        else:
            st.error("Invalid credentials")

# 📝 Register
def register_page():
    st.title("📝 Register")
    username = st.text_input("Choose a Username")
    password = st.text_input("Choose a Password", type="password")
    if st.button("Register"):
        if save_user(username, password):
            st.success("Registration successful! You can now log in.")
        else:
            st.warning("Username already exists!")

# 📸 Weekly Progress
def weekly_progress_tab():
    st.subheader("📸 Upload Your Weekly Transformation Image")
    uploaded = st.file_uploader("Upload Image (JPG/PNG)", type=["jpg", "jpeg", "png"])
    user_dir = os.path.join(UPLOAD_DIR, st.session_state.username)
    os.makedirs(user_dir, exist_ok=True)

    if uploaded:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(user_dir, f"{timestamp}_{uploaded.name}")
        with open(path, "wb") as f:
            f.write(uploaded.getbuffer())
        st.success("Image uploaded successfully!")

    st.markdown("### 🖼️ Your Uploaded Progress Images")
    for file in os.listdir(user_dir):
        if file.lower().endswith(("jpg", "jpeg", "png")):
            st.image(os.path.join(user_dir, file), width=300, caption=file)

# 🍽️ Meals Tab
def meal_tracker_tab():
    st.subheader("🍽 Customize Your Meals")
    target_cals = st.session_state.target_calories
    st.info(f"🎯 Daily Calorie Goal: {target_cals} kcal")

    meal_totals = {}

    for meal in ["Breakfast", "Lunch", "Dinner", "Snacks"]:
        st.markdown(f"#### 🍱 {meal}")
        selected = st.multiselect(f"Choose foods for {meal}", options=[f['name'] for f in food_items], key=meal)
        st.session_state.meal_log[meal] = [
            next((f for f in food_items if f['name'] == item), None) for item in selected
        ]

        cal = sum(f['calories'] for f in st.session_state.meal_log[meal] if f)
        prot = sum(f['protein'] for f in st.session_state.meal_log[meal] if f)
        fat = sum(f['fat'] for f in st.session_state.meal_log[meal] if f)
        meal_totals[meal] = {"calories": cal, "protein": prot, "fat": fat}

        with st.expander(f"{meal} Summary"):
            st.write(f"**Calories**: {cal} kcal | **Protein**: {prot} g | **Fat**: {fat} g")
            for food in st.session_state.meal_log[meal]:
                if food:
                    st.write(f"- {food['name']} → {food['calories']} kcal, {food['protein']}g protein, {food['fat']}g fat")

    # 🔢 Daily Total
    total_cal = sum(meal_totals[m]["calories"] for m in meal_totals)
    total_prot = sum(meal_totals[m]["protein"] for m in meal_totals)
    total_fat = sum(meal_totals[m]["fat"] for m in meal_totals)

    st.markdown("### 🧾 Daily Summary")
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Calories", f"{total_cal} kcal")
    col2.metric("Total Protein", f"{total_prot} g")
    col3.metric("Total Fat", f"{total_fat} g")

    remaining = st.session_state.target_calories - total_cal
    if remaining > 0:
        st.success(f"✅ You can consume ~{remaining} more kcal today.")
    else:
        st.error(f"⚠️ You've exceeded your calorie goal by {-remaining} kcal.")
        with st.expander("💡 Recommendation"):
            st.write("You’ve gone beyond your limit. Consider reviewing your plan in the **Diet Recommendation** tab.")

# 🧠 Dashboard
def dashboard():
    st.title(f"👋 Welcome, {st.session_state.username}")
    tab1, tab2, tab3 = st.tabs(["📋 Diet Recommendation", "🍱 Meals & Nutrition", "📸 Weekly Progress"])

    with tab1:
        st.subheader("🎯 Get Your Personalized Calories")
        with st.form("user_form"):
            age = st.number_input("Age", min_value=10, max_value=100, value=25)
            gender = st.radio("Gender", ["Male", "Female"], horizontal=True)
            weight = st.number_input("Weight (kg)", min_value=30.0, max_value=200.0, value=70.0)
            height = st.number_input("Height (cm)", min_value=100.0, max_value=250.0, value=170.0)
            goal = st.selectbox("Health Goal", ["Weight Loss", "Muscle Gain", "Maintain Weight"])
            submitted = st.form_submit_button("Calculate Recommendation")

        if submitted:
            result = recommend_diet(age, gender, float(weight), float(height), goal)
            st.session_state.target_calories = result["Calories"]
            st.success("✅ Recommendation Generated!")
            st.metric("BMI", result["BMI"])
            st.metric("Weight Category", result["Category"])
            st.metric("Target Calories", f"{result['Calories']} kcal")

            with st.expander("📋 Sample Meal Plan"):
                for meal, item in result["Plan"].items():
                    st.write(f"**{meal}**: {item}")

    with tab2:
        meal_tracker_tab()

    with tab3:
        weekly_progress_tab()

# 📂 Sidebar Navigation
if st.session_state.logged_in:
    menu = st.sidebar.selectbox("📂 Navigation", ["Dashboard", "Logout"])
else:
    menu = st.sidebar.selectbox("📂 Navigation", ["Login", "Register"])

# 🔁 Routing
if menu == "Login":
    login_page()
elif menu == "Register":
    register_page()
elif menu == "Dashboard" and st.session_state.logged_in:
    dashboard()
elif menu == "Logout":
    st.session_state.logged_in = False
    st.session_state.username = None
    st.session_state.meal_log = {"Breakfast": [], "Lunch": [], "Dinner": [], "Snacks": []}
    st.session_state.target_calories = 2000
    st.success("Logged out.")

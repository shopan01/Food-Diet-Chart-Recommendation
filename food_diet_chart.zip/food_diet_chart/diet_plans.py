def get_bmi(weight, height_cm):
    height_m = height_cm / 100
    return weight / (height_m ** 2)

def recommend_diet(age, gender, weight, height, goal):
    bmi = get_bmi(weight, height)

    if goal == "Weight Loss":
        calories = 1500
    elif goal == "Muscle Gain":
        calories = 2500
    else:
        calories = 2000

    if bmi < 18.5:
        category = "Underweight"
    elif 18.5 <= bmi < 25:
        category = "Normal"
    elif 25 <= bmi < 30:
        category = "Overweight"
    else:
        category = "Obese"

    diet_plan = {
        "Breakfast": "Oatmeal with fruit and nuts + Green tea",
        "Mid-morning Snack": "Fruit salad or a protein bar",
        "Lunch": "Grilled chicken/fish, brown rice, veggies, curd",
        "Evening Snack": "Boiled eggs or sprouts + Herbal tea",
        "Dinner": "Soup + Multigrain roti + Mixed vegetables"
    }

    return {
        "BMI": round(bmi, 2),
        "Category": category,
        "Calories": calories,
        "Plan": diet_plan
    }
